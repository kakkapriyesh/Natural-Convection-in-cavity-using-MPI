from mpi4py import MPI
import numpy as np
comm=MPI.COMM_WORLD 
rank=comm.Get_rank()
nProcs=comm.Get_size()
#import matplotlib.pyplot as plt

BS=0; #Boundary south
BN=100; #boundary North

row=100 #cells in  row
col=50#cells in column
Y=100;      #length of yaxis domain

global dy
dy=float(Y)/row;
global F;
global k1;
global k2;
C=[]
global dt


dt=0.01

global Const
Const=10
#print(Const)
A = np.zeros((row, col))  #defining Mesh A(Matrix)
Ut=[]

#print A
OR=float(col)/row;   #Aspect ratio of mesh
diff=1;
diff2=23;

 #mapping nprocs to domain 

if (nProcs==1):
  def fact(nProcs,OR):
    return 1,1
else:
 def fact(nProcs,OR):

		diff_old = 23
		for i in range(1, (nProcs/2)+1):	
			if nProcs % i == 0:
				aspectRatio = i**2/float(nProcs) 
				diff = abs( OR - aspectRatio)
				
				if diff < diff_old:
				   diff_old = diff
				   #print "i",i
		if i*int(nProcs/i)==nProcs:		   
		     return i, int(nProcs/i)
		else:
		     return nProcs,1                      # if cannot factor dividing rows in nprocs
									
iProcs, jProcs = fact(nProcs, float(col/row))

D=np.linspace(0,row,(iProcs+1),dtype=int) 
E=np.linspace(0,col,(jProcs+1),dtype=int) 
#print("D",D,"E",E)

Bi=int(rank/jProcs)   #finding i according to slide,position of mesh
Bj=int(rank%jProcs)

F=0;
K=1;        
k1=0;
k2=0 
ite=1


while(k1!=5 and k2!=20):               #flags
 if (rank==0):                        ##writing seprate module for rank 0 for robustness and ease of codeing as there wont be lag in time as all prc run seprately
   if (ite==1):
    print("\n")
    print "No of cells in X is ",col,"No of cells in Y is ",row
    print("\n")
    print "Boundary condition on North face",BN,"\n",'Boundary condition on south face',BS,"\n",'time step',dt
    print("\n")
    print "No of Processors used ",nProcs
    print("\n")
    print "iProcs ",iProcs,"jProcs",jProcs
    print "\n"
    
    
   if (ite==1):         
   
    for i in range (0,iProcs):      #i is for rows
     for j in range (0,jProcs):
   
      if (i==0 and j==0) :                                                     #For giving the data to its own i.e proc=0
       data1=A[D[j]:D[j+1],E[i]:E[i+1]]
       data1 = np.pad(data1, pad_width=1, mode='constant', constant_values=0)  #defining ghost cells at each decomposed domain
       data1 = np.delete(data1, -1,axis=1)
       data1 = np.delete(data1, 0,axis=1)
       
      else:
       data2=A[D[i]:D[i+1],E[j]:E[j+1]]
       data2 = np.pad(data2, pad_width=1, mode='constant', constant_values=0) #mapping nprocs to domain 
       data2 = np.delete(data2, -1,axis=1)
       data2 = np.delete(data2, 0,axis=1)
       comm.send(data2,dest=i*jProcs+j,tag=11)  #sending data to differnet processors and mapped 
       #print("data",data2,"rank",i*jProcs+j)
    if(ite==1):      #deleting and giving boundaries to domains for the first iteration only
  
     if (Bi==0):
    
      data1 = np.delete(data1, 0,axis=0)
      data1[0]=BN;
      
     if(Bi==(iProcs-1)):
      data1 = np.delete(data1, -1,axis=0)
      data1[-1]=BS
     
    
   r=len(data1)
   c=len(data1[0])
  
   Ut=np.zeros((r,c))
  
   for i in range (1,r-1,1):               #i is for rows
      for j in range (0,c,1):
        
        #applying formula

        Ut[i,j]=data1[i,j]+Const*dt*(1/(dy*dy))*(data1[i+1,j]-2*data1[i,j]+data1[i-1,j])
   
   Res=abs(np.subtract(data1[1:r-1,0:c],Ut[1:r-1,0:c]))
   Ressq=np.square(Res)
   Sum=np.sum(Ressq)
   data1[1:r-1,0:c]=Ut[1:r-1,0:c]; 
   
#communication 
   
   if(Bi<iProcs-1):
  
     comm.send(data1[-2,:],dest=((Bi+1)*jProcs+Bj),tag=12)
     datar=comm.recv(source=((Bi+1)*jProcs+Bj),tag=12)
     data1[-1,:]=datar
    
     
   if(Bi>0):
   
     comm.send(data1[1,:],dest=((Bi-1)*jProcs+Bj),tag=12)
     datar=comm.recv(source=((Bi-1)*jProcs+Bj),tag=12)
     data1[0,:]=datar
   
   if (F==1): 
    if (Bi!=0):
     data1 = np.delete(data1, 0,axis=0)
     
    if(Bi!=(iProcs-1)):
      data1 = np.delete(data1, -1,axis=0)

    k1=5;                      #Flag on if residue is reached
 elif(rank!=0):  
   if(ite==1):
     data1=comm.recv(source=0,tag=11); 
     
   Bi=int(rank/jProcs)
   Bj=int(rank%jProcs)
    
 #trimming ghost cells for gathering

   if(ite==1):      #deleteing and giving boundaries to domains for the first iteration only
  
     if (Bi==0):
    
      data1 = np.delete(data1, 0,axis=0)
      data1[0]=BN;
      
     if(Bi==(iProcs-1)):
      data1 = np.delete(data1, -1,axis=0)
      data1[-1]=BS
     
    
   r=len(data1)
   c=len(data1[0])
   
   Ut=np.zeros((r,c))
  
   for i in range (1,r-1,1):
      for j in range (0,c,1):
        
        #applying formula

        Ut[i,j]=data1[i,j]+Const*dt*(1/(dy*dy))*(data1[i+1,j]-2*data1[i,j]+data1[i-1,j])
  
   Res=abs(np.subtract(data1[1:r-1,0:c],Ut[1:r-1,0:c]))
   Ressq=np.square(Res)
   Sum=np.sum(Ressq)
   data1[1:r-1,0:c]=Ut[1:r-1,0:c]; 
  
 #communication    

   if(Bi<iProcs-1):
  
     comm.send(data1[-2,:],dest=((Bi+1)*jProcs+Bj),tag=12)
     datar=comm.recv(source=((Bi+1)*jProcs+Bj),tag=12)
     data1[-1,:]=datar
    
     
   if(Bi>0):
   
     comm.send(data1[1,:],dest=((Bi-1)*jProcs+Bj),tag=12)
     datar=comm.recv(source=((Bi-1)*jProcs+Bj),tag=12)
     data1[0,:]=datar
   
#trimming ghost cells for gathering

   if (F==1): 
    if (Bi!=0):
     data1 = np.delete(data1, 0,axis=0)
     
    if(Bi!=(iProcs-1)):
      data1 = np.delete(data1, -1,axis=0)

    k2=20;                  #Flag on if residue is reached
 
 
 ite=ite+1
 #print(ite,)     #counting iterations
 res=comm.allgather(Sum)
 RESF=np.sum(res)
 #print(ite,RESF)
 if (RESF<0.000005):   #checking Residue
    F=1;            #assigning Flags for trimming
 
  

L=comm.gather(data1,root=0)   #gathering data1 from all proc
#print("unstructured grid",L)

if rank == 0:
        
		C = np.empty([row, col])
		
		t = 0
		for m in range(0,iProcs):
			for n in range(0,jProcs):
				C[D[m]:D[m+1], E[n]:E[n+1]] = L[t]
				t += 1
			
		print("\n Matrix C is \n")
		print C 
		print "\n","no of iterations required",ite,"\n","\n","Final Residue is",RESF                                     #printing the domain with boundaries
  
#plt.imshow(C);
#plt.axis('off')
#plt.colorbar()
#plt.show()
#plt.savefig("Jacobi2d.png", bbox_inches='tight') 
